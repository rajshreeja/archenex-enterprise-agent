# 30-day pilot playbook

| Week | Do | Output |
|---|---|---|
| 0 | Agree scope: 3-4 datasets, 60-90 days of exports, a named CFO sponsor and plant/HR contacts. Sign data terms | Scope note |
| 1 | Receive exports. Map columns. Run. Sanity-check 20 flagged rows with the client | Clean run, known data caveats |
| 2 | Review with COO/Plant Head: hotspots, root causes, which findings are legitimate exceptions | Tuned assumptions |
| 3 | CFO session: dossier PDF; approve 3-5 actions live in the Action Queue | Signed-off action list |
| 4 | Owners act. Re-run on fresh data. Record **measured** recovery per rule | Before/after, proof for renewal |

**Success criteria (agree up front):** at least one approved action with measurable recovery; client confirms the
numbers trace to their rows; client asks for the monitor.

**After the pilot:** replace planning realisation rates with measured ones, write a one-page anonymised case study.
