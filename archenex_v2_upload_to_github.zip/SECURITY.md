# Data handling & security note (draft, current state)

*Not legal advice. Have counsel review before sending to a client.*

**What the app does today**
- Client files are read into memory for the session and are not written to disk or a database by this app.
- No data is sent to third parties, except the optional AI brief, which sends only aggregated totals (no employee IDs, e-mails or names) to Anthropic's API, and only if you add an API key.
- Optional access code via Streamlit Secrets (`APP_PASSWORD`).
- Every recommended action requires a named human decision; decisions are logged (per session, downloadable).
- ArcheNex never writes back to HRIS, payroll or ERP.

**What it does NOT do yet**
- No single sign-on, role-based access or per-client data separation.
- Audit trail is not persisted or tamper-evident beyond the report fingerprint.
- Streamlit Community Cloud is a shared public host: use it for demos and synthetic data only.
  For real client data, host in an India region (AWS Mumbai / Azure Central India) with access control.
- No independent security assessment.

**Personal data**
Attendance, gate-swipe and payroll data is personal data under India's DPDP Act, 2023.
Before a pilot: get a written data-processing agreement, minimise fields (pseudonymise
employee IDs where possible), agree retention and deletion, and name a contact for data requests.

**Labour-law caution**
Idle-time and gate-swipe findings are exceptions for review, not grounds for withholding wages.
Get labour-law advice before any payroll action.
