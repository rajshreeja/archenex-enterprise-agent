# ArcheNex Enterprise Agent (v2.0)

Finds cost leaking between plant, HR and finance systems, from the client's own
file exports. Every rupee figure traces back to flagged rows. No random or
hard-coded results.

## What changed from v1
| v1 | v2 |
|---|---|
| Leakage = headcount × constants × slider | Five rule-based detectors run on real files |
| Audit log = random numbers | Audit log = the actual flagged rows, filterable and downloadable |
| Fixed "hash" (SHA-256 of empty text) | Real SHA-256 over inputs + assumptions + findings, with an in-app verifier |
| "Auto-pauses payroll" | Recommends actions; a person approves each one; decisions are logged |
| ₹ missing in the PDF | Rupee-safe fonts, A4, wrapped tables, DRAFT/sign-off block |
| One 380-line file | `app.py` (screens) · `detectors.py` (engine) · `agent_model.py` (actions) · `report.py` (PDF) · `demo_data.py` |

## Update your GitHub repo (no coding)
1. Unzip the download.
2. Open your repo on github.com, click **Add file → Upload files**.
3. Drag in **all** the unzipped files (including the `template_*.csv` files).
   Files with the same name (`app.py`, `agent_model.py`, `requirements.txt`) are replaced.
4. Scroll down, click **Commit changes**.
5. Your Streamlit app redeploys by itself in 1-3 minutes. If it shows an error:
   open the app → **Manage app** (bottom right) → read the log, and send it to me.

## Optional settings (Streamlit → your app → Settings → Secrets)
```
APP_PASSWORD = "choose-a-strong-code"        # adds a login screen
ANTHROPIC_API_KEY = "sk-ant-..."             # enables the AI-written CFO brief
```
Without these the app still works fully (open access, no AI brief).

## Using it with a real client
1. Sidebar → **Data source → Upload client files**.
2. **0. Data & Setup** → download the four `template_*.csv` files; they show the exact columns.
3. Fill them from the client's exports (Keka/Darwinbox attendance, machine log, ERP milestones, IT licence report). Excel is fine.
4. Upload. Each rule runs as soon as its files are present; send 60-90 days of data for reliable annualisation.
5. Review **Action Queue**, then **Report & Verify → Build PDF report**.

## How the numbers are built
| Rule | Logic |
|---|---|
| Idle-time labour cost | Avoidable idle hours × workers on paid roster × avg hourly rate |
| Paid shifts with no gate swipe | Paid hours × rate where no gate-in exists |
| Overtime on under-utilised cells | OT hours × rate × multiplier where cell utilisation < threshold |
| Delayed milestone invoicing | Value × cost of capital × days beyond grace ÷ 365 |
| Orphaned SaaS | Monthly cost × 12 for licences inactive > N days or belonging to exited staff |

"Addressable" = identified × a realisation rate per rule. These rates are
**planning assumptions** (editable in the sidebar) until a pilot measures real recovery.

## Not built yet (be honest with clients)
Live API connectors (exports only), single sign-on, a database with persistent
multi-client data, persistent audit trail, penetration test / ISO 27001.
See `SECURITY.md`.
