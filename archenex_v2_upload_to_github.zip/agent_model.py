"""
ArcheNex agent layer.

Design principle: DETECT with transparent rules, RECOMMEND actions, and let a HUMAN
approve every one. Every decision is logged. ArcheNex never changes payroll, ERP or
HRIS data on its own in this version; execution stays with the client's teams until
write-back connectors are deliberately enabled.
"""
from __future__ import annotations

import pandas as pd

from detectors import Finding, inr


def _factor(f: Finding) -> float:
    """Scale factor from in-window cost to annual cost."""
    return f.annualised_inr / f.observed_inr if f.observed_inr > 0 else 0.0


def recommend_actions(findings: list[Finding], cfg: dict) -> list[dict]:
    actions: list[dict] = []
    by_key = {f.key: f for f in findings}

    f = by_key.get("idle_staging")
    if f is not None and len(f.evidence):
        g = (f.evidence.groupby(["cell", "shift"])
             .agg(cost=("impact_inr", "sum"), hours=("idle_hours", "sum"), events=("impact_inr", "size"))
             .sort_values("cost", ascending=False).head(3).reset_index())
        for i, r in g.iterrows():
            actions.append({
                "id": f"idle_staging-{i}", "detector": f.key, "owner": "Plant Head / Supply Chain",
                "title": f"Fix material staging at {r.cell}, Shift {r['shift']}",
                "detail": (f"{r.events} staging stoppages totalling {r.hours:.0f} idle hours cost about "
                           f"{inr(r.cost)} in labour in the data window. Review the material feed "
                           "schedule and redeploy crews during staging gaps."),
                "impact_inr_annual": float(r.cost * _factor(f)),
            })

    f = by_key.get("ghost_attendance")
    if f is not None and len(f.evidence):
        g = (f.evidence.groupby("cell")
             .agg(cost=("impact_inr", "sum"), n=("impact_inr", "size"))
             .sort_values("cost", ascending=False).head(3).reset_index())
        for i, r in g.iterrows():
            actions.append({
                "id": f"ghost_attendance-{i}", "detector": f.key, "owner": "HR Operations + Plant HR",
                "title": f"Reconcile paid shifts with no gate swipe in {r.cell}",
                "detail": (f"{r.n} paid shifts ({inr(r.cost)} in the window) have no gate-in record. "
                           "Check against biometric device logs and manual regularisations before "
                           "any payroll action."),
                "impact_inr_annual": float(r.cost * _factor(f)),
            })

    f = by_key.get("overtime_underutil")
    if f is not None and len(f.evidence):
        g = (f.evidence.groupby("cell")
             .agg(cost=("impact_inr", "sum"), n=("impact_inr", "size"), util=("utilisation_pct", "mean"))
             .sort_values("cost", ascending=False).head(3).reset_index())
        for i, r in g.iterrows():
            actions.append({
                "id": f"overtime_underutil-{i}", "detector": f.key, "owner": "Plant Head + Finance",
                "title": f"Review overtime approvals in {r.cell}",
                "detail": (f"{r.n} overtime entries ({inr(r.cost)}) were paid while the cell averaged "
                           f"{r.util:.0f}% utilisation. Tighten approval rules or confirm the backlog "
                           "justification."),
                "impact_inr_annual": float(r.cost * _factor(f)),
            })

    f = by_key.get("milestone_delay")
    if f is not None and len(f.evidence):
        top = f.evidence.sort_values("value_inr", ascending=False).head(5)
        for i, (_, r) in enumerate(top.iterrows()):
            actions.append({
                "id": f"milestone_delay-{i}", "detector": f.key, "owner": "Finance + Project Delivery",
                "title": f"Invoice or escalate {r.project} ({r.client})",
                "detail": (f"Signed off {r.date}; {r.status.lower()} after {r.lag_days} days; "
                           f"milestone value {inr(r.value_inr)}. Raise the invoice or escalate "
                           "the blocked approval."),
                "impact_inr_annual": float(r.impact_inr * _factor(f)),
            })

    f = by_key.get("orphaned_saas")
    if f is not None and len(f.evidence):
        g = (f.evidence.groupby("app")
             .agg(cost=("impact_inr", "sum"), n=("impact_inr", "size"))
             .sort_values("cost", ascending=False).head(3).reset_index())
        for i, r in g.iterrows():
            actions.append({
                "id": f"orphaned_saas-{i}", "detector": f.key, "owner": "IT + Finance",
                "title": f"Reclaim {r.n} unused {r.app} licences",
                "detail": (f"{r.n} seats are inactive or belong to exited employees, costing "
                           f"{inr(r.cost)} a year. Confirm they are not shared accounts, then reclaim."),
                "impact_inr_annual": float(r.cost),
            })

    return sorted(actions, key=lambda a: a["impact_inr_annual"], reverse=True)


def audit_trail_df(log: list[dict]) -> pd.DataFrame:
    cols = ["timestamp", "reviewer", "action_id", "action", "decision"]
    return pd.DataFrame(log, columns=cols) if log else pd.DataFrame(columns=cols)


def summary_text(findings: list[Finding], summary: dict) -> str:
    """Aggregated numbers only (no employee IDs or e-mails) - safe to send to an LLM."""
    lines = [f"Total identified annual leakage: {inr(summary['identified_annual'])}",
             f"Realistically addressable: {inr(summary['addressable_annual'])}"]
    for f in findings:
        lines.append(f"- {f.title}: {f.rows_flagged} items flagged, annualised {inr(f.annualised_inr)}. "
                     f"Method: {f.method}")
    return "\n".join(lines)


def ai_brief(text: str, api_key: str) -> str:
    """Optional: plain-English CFO brief written by Claude from AGGREGATED numbers only."""
    try:
        import anthropic  # imported lazily so the app works without it

        client = anthropic.Anthropic(api_key=api_key)
        msg = client.messages.create(
            model="claude-sonnet-5-5",
            max_tokens=700,
            system=("You write concise briefings for a CFO. Use ONLY the numbers provided. Do not "
                    "invent figures, causes or benchmarks. Note that realisation rates are planning "
                    "assumptions. Finish with the 3 most valuable next steps."),
            messages=[{"role": "user", "content": text}],
        )
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    except Exception as e:  # network, key, quota ...
        return f"AI brief unavailable: {type(e).__name__}: {e}"
