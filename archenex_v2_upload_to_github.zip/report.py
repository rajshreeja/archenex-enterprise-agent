"""Boardroom PDF report. Uses DejaVu fonts (bundled with matplotlib) so the ₹ symbol renders."""
import io
import os
from datetime import datetime
from xml.sax.saxutils import escape

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (CondPageBreak, Image, KeepTogether, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

from detectors import TOOL_VERSION, inr

NAVY, BLUE, GREY, RED = "#1e3a8a", "#2563eb", "#64748b", "#b91c1c"
_FONTS_READY = False


def _fonts():
    global _FONTS_READY
    if _FONTS_READY:
        return
    base = os.path.join(matplotlib.get_data_path(), "fonts", "ttf")
    pdfmetrics.registerFont(TTFont("DejaVu", os.path.join(base, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DejaVu-Bold", os.path.join(base, "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold",
                                  italic="DejaVu", boldItalic="DejaVu-Bold")
    _FONTS_READY = True


def _chart(findings, cfg) -> io.BytesIO:
    names = [f.title.split(" (")[0] for f in findings]
    ident = [f.annualised_inr / 1e5 for f in findings]
    addr = [f.addressable(cfg) / 1e5 for f in findings]
    fig, ax = plt.subplots(figsize=(7.2, 2.8))
    y = range(len(names))
    ax.barh([i + 0.2 for i in y], ident, height=0.38, color="#94a3b8", label="Identified (annual)")
    ax.barh([i - 0.2 for i in y], addr, height=0.38, color=NAVY, label="Addressable (annual)")
    ax.set_yticks(list(y))
    ax.set_yticklabels(names, fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel("₹ Lakhs per year", fontsize=7)
    ax.tick_params(axis="x", labelsize=7)
    ax.legend(fontsize=7, frameon=False, loc="lower right")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=200)
    plt.close(fig)
    buf.seek(0)
    return buf


def build_pdf(meta: dict, findings: list, summary: dict, cfg: dict, fingerprint: str,
              reviewer: str = "") -> bytes:
    _fonts()
    ss = getSampleStyleSheet()
    H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontName="DejaVu-Bold", fontSize=15,
                        textColor=colors.HexColor(NAVY), spaceAfter=4)
    H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontName="DejaVu-Bold", fontSize=11,
                        textColor=colors.HexColor(BLUE), spaceBefore=10, spaceAfter=4, keepWithNext=1)
    B = ParagraphStyle("B", parent=ss["Normal"], fontName="DejaVu", fontSize=9, leading=13, spaceAfter=4)
    SM = ParagraphStyle("SM", parent=B, fontSize=7.5, leading=10, textColor=colors.HexColor(GREY))
    MONO = ParagraphStyle("MONO", parent=B, fontName="Courier", fontSize=7.5, leading=10)
    WARN = ParagraphStyle("WARN", parent=B, fontName="DejaVu-Bold", textColor=colors.HexColor(RED))

    def tbl(data, widths, header=True, align_right_from=None):
        t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
        st = [("FONTNAME", (0, 0), (-1, -1), "DejaVu"), ("FONTSIZE", (0, 0), (-1, -1), 8),
              ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#cbd5e1")),
              ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#e2e8f0")),
              ("VALIGN", (0, 0), (-1, -1), "TOP"),
              ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
        if header:
            st += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(NAVY)),
                   ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                   ("FONTNAME", (0, 0), (-1, 0), "DejaVu-Bold")]
        if align_right_from is not None:
            st.append(("ALIGN", (align_right_from, 0), (-1, -1), "RIGHT"))
        t.setStyle(TableStyle(st))
        return t

    def cell(txt):  # wrap long text inside tables
        return Paragraph(escape(str(txt)), ParagraphStyle("c", parent=B, fontSize=8, leading=10, spaceAfter=0))

    story = []
    story.append(Paragraph("ARCHENEX AUDIT DOSSIER", H1))
    story.append(Paragraph("Cross-silo financial leakage review - draft for board sub-committee", SM))
    story.append(Spacer(1, 4))
    if meta["is_demo"]:
        story.append(Paragraph("SYNTHETIC DEMONSTRATION DATA - NOT FINDINGS FOR ANY REAL COMPANY", WARN))

    now = datetime.now().strftime("%d %b %Y, %H:%M")
    story.append(tbl([
        ["Organisation", cell(meta["client"]), "Report date", cell(now)],
        ["Industry", cell(meta["sector"]), "Data basis", cell(meta["data_basis"])],
        ["Source systems", cell(f"{meta['hris']} / {meta['erp']} (file exports)"),
         "Engine version", cell(TOOL_VERSION)],
    ], [28 * mm, 66 * mm, 26 * mm, 54 * mm], header=False))

    story.append(Paragraph("1. Headline numbers", H2))
    pb = summary["payback_months"]
    hl = [
        ["Measure", "Value", "How it is derived"],
        ["Identified annual leakage", inr(summary["identified_annual"]),
         "Sum of rule findings, scaled from the data window to 12 months"],
        ["Realistically addressable", inr(summary["addressable_annual"]),
         "Identified × realisation rate per rule (planning assumption)"],
        ["Illustrative valuation lift", inr(summary["valuation_lift"]),
         f"Addressable × {cfg['ev_ebitda_multiple']:g}x. Only valid if savings are recurring and verified"],
        ["Platform fee (assumed)", inr(summary["fee"]), "Annual subscription used in the payback maths"],
        ["Return on fee", f"{summary['roi_multiple']:.1f}x per year",
         f"Payback in {pb:.1f} months" if pb != float("inf") else "n/a"],
        ["One-time cash release", inr(summary["one_time_cash_release"]),
         "Unbilled milestones; working capital, not annual savings"],
    ]
    hl = [hl[0]] + [[r[0], r[1], cell(r[2])] for r in hl[1:]]
    story.append(tbl(hl, [48 * mm, 30 * mm, 96 * mm]))

    story.append(Paragraph("2. Findings by audit rule", H2))
    rows = [["Rule", "Flagged", "Window", "Identified / yr", "Real. %", "Addressable / yr"]]
    for f in findings:
        rows.append([cell(f.title), f"{f.rows_flagged:,}", f"{f.window_days}d",
                     inr(f.annualised_inr), f"{cfg['realisation_pct'].get(f.key, 0):g}%",
                     inr(f.addressable(cfg))])
    story.append(tbl(rows, [62 * mm, 18 * mm, 16 * mm, 30 * mm, 15 * mm, 33 * mm], align_right_from=1))
    story.append(Spacer(1, 6))
    if findings:
        story.append(Image(_chart(findings, cfg), width=170 * mm, height=66 * mm))

    story.append(CondPageBreak(70 * mm))
    story.append(Paragraph("3. Method and limitations", H2))
    for f in findings:
        story.append(KeepTogether([
            Paragraph(f"<b>{escape(f.title)}</b>", B),
            Paragraph(escape(f.method), B),
            Paragraph("<i>Limitation:</i> " + escape(f.caveat or "None noted."), SM),
        ]))
    story.append(Paragraph(
        "All figures are computed from the files supplied. Realisation rates are planning "
        "assumptions until a pilot produces measured recovery. Findings are exceptions for human "
        "review, not conclusions of wrongdoing, and no payroll or ERP data has been altered.", SM))

    story.append(Paragraph("4. Assumptions used", H2))
    arows = [["Assumption", "Value"],
             ["Cost of capital", f"{cfg['cost_of_capital_pct']:g}%"],
             ["Overtime multiplier", f"{cfg['overtime_multiplier']:g}x"],
             ["Invoice grace period", f"{cfg['invoice_grace_days']} days"],
             ["SaaS inactivity threshold", f"{cfg['saas_inactive_days']} days"],
             ["Under-utilisation threshold", f"{cfg['low_utilisation_pct']:g}%"],
             ["Avoidable downtime reasons", escape(str(cfg["avoidable_reasons"]))],
             ["EV/EBITDA multiple (illustrative)", f"{cfg['ev_ebitda_multiple']:g}x"]]
    story.append(tbl(arows, [70 * mm, 50 * mm]))

    story.append(Paragraph("5. Integrity fingerprint", H2))
    story.append(Paragraph(
        "The SHA-256 fingerprint below is computed over the input-file hashes, the assumptions and "
        "the findings. Anyone holding the accompanying findings JSON can recompute it; if a single "
        "figure or assumption is altered, the fingerprint no longer matches. It proves integrity, "
        "not authorship; it is not a digital signature.", B))
    story.append(Paragraph(fingerprint, MONO))

    story.append(Paragraph("6. Human review and sign-off", H2))
    story.append(Paragraph("Status: <b>DRAFT - pending human review.</b> This report becomes final only "
                           "when signed below.", B))
    story.append(tbl([
        ["Prepared / reviewed by", escape(reviewer) if reviewer else "", "Date", ""],
        ["CFO / approving executive", "", "Date", ""],
    ], [48 * mm, 70 * mm, 14 * mm, 42 * mm], header=False))

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("DejaVu", 7)
        canvas.setFillColor(colors.HexColor(GREY))
        canvas.drawString(15 * mm, 9 * mm, f"ArcheNex · {meta['client']} · DRAFT - pending human review")
        canvas.drawRightString(A4[0] - 15 * mm, 9 * mm, f"Page {doc.page}")
        canvas.restoreState()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=14 * mm, bottomMargin=16 * mm,
                            title="ArcheNex Audit Dossier", author="ArcheNex")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()
