import hmac
import html
import io
import json
import zipfile
from datetime import datetime

import pandas as pd
import streamlit as st

import agent_model as ag
import detectors as dt
from demo_data import make_demo, templates
from report import build_pdf

st.set_page_config(page_title="ArcheNex Enterprise Intelligence", page_icon="⚡", layout="wide")

st.markdown("""
<style>
.stApp { background-color:#f8fafc; color:#0f172a; }
[data-testid="stSidebar"] { background-color:#ffffff; border-right:1px solid #e2e8f0; }
[data-testid="stMetric"] { background:#ffffff; border:1px solid #cbd5e1; border-top:4px solid #1e3a8a;
  border-radius:6px; padding:14px 16px; box-shadow:0 1px 3px rgba(0,0,0,.05); }
.plain { background:#eff6ff; border-left:4px solid #2563eb; padding:14px 18px; border-radius:0 6px 6px 0;
  color:#1e3a8a; font-size:14px; line-height:1.6; margin:12px 0; }
.action { background:#f0fdf4; border-left:4px solid #16a34a; padding:14px 18px; border-radius:0 6px 6px 0;
  color:#14532d; font-size:14px; line-height:1.6; margin:12px 0; }
.stButton>button, .stDownloadButton>button { background:#1e3a8a; color:#fff; border:none; border-radius:4px; font-weight:600; }
.stButton>button:hover, .stDownloadButton>button:hover { background:#1d4ed8; color:#fff; }
</style>
""", unsafe_allow_html=True)


# ------------------------------------------------------------------ access gate
def _secret(name):
    try:
        return st.secrets.get(name, None)
    except Exception:
        return None


def access_gate():
    """If APP_PASSWORD is set in Streamlit Secrets, require it. Otherwise the app is open (demo)."""
    pw = _secret("APP_PASSWORD")
    if not pw or st.session_state.get("authed"):
        return
    st.markdown("### ArcheNex Enterprise Intelligence")
    entered = st.text_input("Access code", type="password")
    if st.button("Sign in"):
        if hmac.compare_digest(str(entered), str(pw)):
            st.session_state["authed"] = True
            st.rerun()
        else:
            st.error("Incorrect access code.")
    st.stop()


access_gate()


# ----------------------------------------------------------------------- caching
@st.cache_data(show_spinner="Generating synthetic demo data…")
def load_demo():
    return make_demo()


@st.cache_data(show_spinner="Running audit rules…")
def run_cached(data, cfg_json):
    return dt.run_all(data, json.loads(cfg_json))


def now_stamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ----------------------------------------------------------------------- sidebar
sb = st.sidebar
sb.markdown("### Engagement")
client_name = sb.text_input("Target organisation", "Demo Precision Engineering Pvt Ltd (synthetic)")
industry = sb.selectbox("Industry vertical", ["Auto-Component Manufacturing", "Industrial Tooling & Machinery",
                                              "Precision Casting & Foundry", "Contract Logistics & SC"])
hris = sb.selectbox("HRIS / attendance system (export source)",
                    ["Darwinbox", "Workday HCM", "SAP SuccessFactors", "Keka HR", "greytHR", "Other"])
erp = sb.selectbox("ERP / CRM (export source)",
                   ["SAP S/4HANA", "Microsoft Dynamics 365", "Oracle NetSuite", "Infor CloudSuite", "Other"])
reviewer = sb.text_input("Reviewer name (recorded in audit trail)", "")
source = sb.radio("Data source", ["Synthetic demo data", "Upload client files"])
is_demo = source == "Synthetic demo data"

cfg = json.loads(json.dumps(dt.DEFAULT_CONFIG))  # deep copy
with sb.expander("Assumptions (editable)"):
    cfg["cost_of_capital_pct"] = st.number_input("Cost of capital (%)", 0.0, 40.0, cfg["cost_of_capital_pct"], 0.5)
    cfg["overtime_multiplier"] = st.number_input("Overtime pay multiplier", 1.0, 3.0, cfg["overtime_multiplier"], 0.25)
    cfg["invoice_grace_days"] = st.number_input("Invoice grace period (days)", 0, 60, cfg["invoice_grace_days"])
    cfg["saas_inactive_days"] = st.number_input("SaaS inactivity threshold (days)", 7, 365, cfg["saas_inactive_days"])
    cfg["low_utilisation_pct"] = st.number_input("Under-utilisation threshold (%)", 10.0, 100.0, cfg["low_utilisation_pct"], 5.0)
    cfg["avoidable_reasons"] = st.text_input("Avoidable downtime reasons (comma-separated)", cfg["avoidable_reasons"])
    cfg["ev_ebitda_multiple"] = st.number_input("EV/EBITDA multiple (illustrative)", 1.0, 40.0, cfg["ev_ebitda_multiple"], 0.5)
    cfg["annual_fee_inr"] = st.number_input("Annual platform fee (₹)", 0, 100_000_000, cfg["annual_fee_inr"], 100_000)
    st.caption("Share of each leak realistically recoverable (planning assumptions until a pilot "
               "gives measured numbers):")
    for k in list(cfg["realisation_pct"]):
        cfg["realisation_pct"][k] = st.slider(k.replace("_", " ").title(), 0.0, 100.0,
                                              float(cfg["realisation_pct"][k]), 5.0, key=f"real_{k}")

# -------------------------------------------------------------------------- data
if is_demo:
    data = load_demo()
else:
    data = st.session_state.get("uploaded_data", {})

findings, notes = ([], [])
summary = None
if data:
    findings, notes = run_cached(data, json.dumps(cfg, sort_keys=True))
    if findings:
        summary = dt.summarise(findings, cfg)
data_basis = "SYNTHETIC DEMO DATA" if is_demo else "Client-supplied files"

PAGES = ["0. Data & Setup", "1. Executive Cockpit", "2. Audit Log (line items)",
         "3. Plant: MES & HRIS", "4. Billing & SaaS", "5. Action Queue (approvals)",
         "6. Report & Verify"]
page = sb.radio("Module", PAGES, index=1 if findings else 0)

# ------------------------------------------------------------------------ header
st.markdown("### ARCHENEX ENTERPRISE GOVERNANCE & AUDIT SUITE")
status = ("<span style='color:#b45309;font-weight:bold;'>DEMO MODE</span>" if is_demo else
          "<span style='color:#16a34a;font-weight:bold;'>CLIENT DATA LOADED</span>" if findings else
          "<span style='color:#64748b;font-weight:bold;'>AWAITING DATA</span>")
st.markdown(f"**Client:** {html.escape(client_name)} &nbsp;|&nbsp; **Exports from:** "
            f"{html.escape(hris)} + {html.escape(erp)} &nbsp;|&nbsp; **Status:** {status}",
            unsafe_allow_html=True)
if is_demo:
    st.warning("SYNTHETIC DEMO DATA: every number on screen comes from invented data and is "
               "illustrative only. Choose 'Upload client files' in the sidebar to analyse real exports.")
st.markdown("---")


def get(key):
    return next((f for f in findings if f.key == key), None)


def need_data():
    st.info("No analysable data yet. Open **0. Data & Setup** to upload client exports "
            "or switch to the synthetic demo.")
    st.stop()


# =============================================================== 0. DATA & SETUP
if page == PAGES[0]:
    st.subheader("Data & Setup")
    st.markdown("ArcheNex analyses **file exports** (CSV or Excel) from your plant, HR and finance systems. "
                "Live API connectors are the next phase; exports let you start a pilot without IT integration. "
                "Files are processed in memory and are not stored by this app.")

    if is_demo:
        st.success("Using the built-in synthetic demo dataset.")
    else:
        st.markdown("Upload any of the four files; each rule runs as soon as its inputs are present.")
        up = st.session_state.setdefault("uploaded_data", {})
        for name, label in dt.DATASET_LABELS.items():
            f = st.file_uploader(f"{label}  ·  `{name}`", type=["csv", "xlsx", "xls"], key=f"up_{name}")
            if f is not None:
                try:
                    df = pd.read_excel(f) if f.name.lower().endswith(("xlsx", "xls")) else pd.read_csv(f)
                    df = dt.normalise_columns(df)
                    miss = dt.missing_columns(name, df)
                    if miss:
                        st.error(f"{f.name}: missing columns {', '.join(miss)}. "
                                 f"Required: {', '.join(dt.REQUIRED[name])}")
                    else:
                        up[name] = df
                        st.success(f"{f.name}: {len(df):,} rows loaded.")
                except Exception as e:
                    st.error(f"Could not read {f.name}: {e}")
        if up and st.button("Clear uploaded data"):
            st.session_state["uploaded_data"] = {}
            st.rerun()

    st.markdown("#### Required file formats")
    st.caption("Download the templates, fill them from your HRIS / MES / ERP exports, then upload.")
    tpl = templates()
    cols = st.columns(4)
    for c, (name, df) in zip(cols, tpl.items()):
        c.download_button(f"template_{name}.csv", df.to_csv(index=False).encode("utf-8"),
                          file_name=f"template_{name}.csv", mime="text/csv", key=f"tpl_{name}")
    for name, df in tpl.items():
        with st.expander(f"{dt.DATASET_LABELS[name]}: columns & example"):
            st.dataframe(df)

    if is_demo:
        zbuf = io.BytesIO()
        with zipfile.ZipFile(zbuf, "w", zipfile.ZIP_DEFLATED) as z:
            for name, df in data.items():
                z.writestr(f"demo_{name}.csv", df.to_csv(index=False))
        st.markdown("#### Try the upload path")
        st.download_button("Download the demo dataset as CSV files (.zip)", zbuf.getvalue(),
                           file_name="archenex_demo_data.zip", mime="application/zip")
        st.caption("Unzip, switch the sidebar to 'Upload client files' and upload them to see the real workflow.")

    if data:
        st.markdown("#### Loaded data")
        for name, df in data.items():
            st.markdown(f"**{dt.DATASET_LABELS[name]}**: {len(df):,} rows")
            st.dataframe(df.head(8))
    for n in notes:
        st.caption(f"ℹ️ {n}")
    st.stop()

# everything below needs findings
if not findings:
    need_data()

# ============================================================ 1. EXECUTIVE COCKPIT
if page == PAGES[1]:
    st.subheader("Executive Cockpit: financial leakage found in your data")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Identified annual leakage", dt.inr(summary["identified_annual"]),
              help="Sum of all rule findings, scaled from the data window to 12 months.")
    c2.metric("Realistically addressable", dt.inr(summary["addressable_annual"]),
              help="Identified × realisation rate per rule. Realisation rates are planning assumptions.")
    c3.metric("Return on platform fee", f"{summary['roi_multiple']:.1f}x / yr",
              delta=(f"payback {summary['payback_months']:.1f} months"
                     if summary["payback_months"] != float("inf") else None), delta_color="off")
    c4.metric("Illustrative valuation lift", dt.inr(summary["valuation_lift"]),
              help=f"Addressable × {cfg['ev_ebitda_multiple']:g}x. Valid only for recurring, verified savings.")

    st.markdown(
        f"<div class='plain'><b>In plain English:</b> ArcheNex checked {sum(f.rows_checked for f in findings):,} "
        f"records across {len(findings)} audit rules and flagged {summary['rows_flagged']:,} items. Scaled to a "
        f"year, they point to about <b>{dt.inr(summary['identified_annual'])}</b> of cost leaking between "
        f"your plant, HR and finance systems. Using conservative recovery assumptions, about "
        f"<b>{dt.inr(summary['addressable_annual'])}</b> a year is realistically addressable. Separately, "
        f"<b>{dt.inr(summary['one_time_cash_release'])}</b> of milestones were never invoiced: a one-time cash "
        f"release, not an annual saving.</div>", unsafe_allow_html=True)

    left, right = st.columns(2)
    chart = pd.DataFrame({
        "Identified (₹ L / yr)": [f.annualised_inr / 1e5 for f in findings],
        "Addressable (₹ L / yr)": [f.addressable(cfg) / 1e5 for f in findings],
    }, index=[f.title.split(" (")[0] for f in findings])
    with left:
        st.markdown("#### Leakage by audit rule (₹ Lakhs / year)")
        st.bar_chart(chart, color=["#94a3b8", "#1e3a8a"], horizontal=True)
    with right:
        st.markdown("#### Findings summary")
        st.dataframe(pd.DataFrame({
            "Rule": [f.title for f in findings],
            "Flagged": [f.rows_flagged for f in findings],
            "Identified / yr": [dt.inr(f.annualised_inr) for f in findings],
            "Realisation": [f"{cfg['realisation_pct'].get(f.key, 0):g}%" for f in findings],
            "Addressable / yr": [dt.inr(f.addressable(cfg)) for f in findings],
        }), hide_index=True)

    with st.expander("How these numbers are built, and their limits"):
        for f in findings:
            st.markdown(f"**{f.title}**: {f.method}")
            if f.caveat:
                st.caption(f.caveat)
    for n in notes:
        st.caption(f"ℹ️ {n}")

# ================================================================= 2. AUDIT LOG
elif page == PAGES[2]:
    st.subheader("Audit Log: every flagged line item")
    st.markdown("Each row is a real record from the supplied files that tripped a rule. "
                "Nothing here is simulated.")
    log = pd.concat([f.evidence[dt._STD].assign(rule=f.title) for f in findings], ignore_index=True)
    fc1, fc2 = st.columns([2, 1])
    picked = fc1.multiselect("Rule", sorted(log["rule"].unique()), default=sorted(log["rule"].unique()))
    min_imp = fc2.number_input("Minimum impact (₹)", 0, 10_000_000, 0, 1000)
    view = log[log["rule"].isin(picked) & (log["impact_inr"] >= min_imp)]
    view = view.sort_values("impact_inr", ascending=False)[["rule", "date", "where", "detail", "impact_inr"]]
    st.caption(f"{len(view):,} line items · {dt.inr(view['impact_inr'].sum())} observed in the data window "
               "(before annualisation)")
    st.dataframe(view, hide_index=True)
    st.download_button("Download filtered log (CSV)", view.to_csv(index=False).encode("utf-8"),
                       file_name="archenex_audit_log.csv", mime="text/csv")

# ======================================================================= 3. PLANT
elif page == PAGES[3]:
    st.subheader("Plant: machine log × attendance")
    idle, ghost, ot = get("idle_staging"), get("ghost_attendance"), get("overtime_underutil")
    if not (idle or ghost or ot):
        st.info("Upload the attendance and machine-log files to enable this module.")
        st.stop()
    c1, c2, c3 = st.columns(3)
    if idle:
        c1.metric("Idle-time labour cost / yr", dt.inr(idle.annualised_inr),
                  delta=f"{idle.evidence['idle_hours'].sum():,.0f} avoidable idle hours in window", delta_color="off")
    if ghost:
        c2.metric("Paid shifts with no gate swipe / yr", dt.inr(ghost.annualised_inr),
                  delta=f"{ghost.rows_flagged:,} shifts to verify", delta_color="off")
    if ot:
        c3.metric("Overtime on under-utilised cells / yr", dt.inr(ot.annualised_inr),
                  delta=f"{ot.rows_flagged:,} entries to review", delta_color="off")

    if idle and len(idle.evidence):
        a, b = st.columns(2)
        ev = idle.evidence
        with a:
            st.markdown("#### Idle-time labour cost by cell (₹ Lakhs, in window)")
            st.bar_chart(ev.groupby("cell")["impact_inr"].sum() / 1e5, color="#1e3a8a")
        with b:
            st.markdown("#### Hotspot map: cell × shift (₹ Lakhs)")
            heat = (ev.pivot_table(index="cell", columns="shift", values="impact_inr", aggfunc="sum")
                    .fillna(0) / 1e5)
            st.dataframe(heat.style.format("{:.1f}").background_gradient(cmap="Blues"))
        st.markdown(
            f"<div class='plain'><b>What is happening?</b> On days when material staging stalls a cell, the "
            f"machines stop but the crew stays on the paid roster. The data shows "
            f"{idle.rows_flagged} such stoppages in {idle.window_days} days.</div>"
            f"<div class='action'><b>How it is recovered:</b> by fixing the staging schedule or redeploying crews "
            f"into the idle window, not by withholding wages. See <b>5. Action Queue</b>.</div>",
            unsafe_allow_html=True)
    if ghost and len(ghost.evidence):
        st.markdown("#### Paid shifts with no gate swipe: by cell")
        st.bar_chart(ghost.evidence.groupby("cell")["impact_inr"].sum() / 1e5, color="#dc2626")
        st.caption(ghost.caveat)
    if ot and len(ot.evidence):
        st.markdown("#### Overtime paid on under-utilised cells: by cell")
        st.bar_chart(ot.evidence.groupby("cell")["impact_inr"].sum() / 1e5, color="#2563eb")
        st.caption(ot.caveat)

# ============================================================== 4. BILLING & SAAS
elif page == PAGES[4]:
    st.subheader("Billing & SaaS reconciliation")
    ms, sa = get("milestone_delay"), get("orphaned_saas")
    if not (ms or sa):
        st.info("Upload the milestones and SaaS files to enable this module.")
        st.stop()
    c1, c2, c3 = st.columns(3)
    if ms:
        c1.metric("Value-weighted invoicing delay", f"{ms.extra['value_weighted_delay_days']:.0f} days beyond grace")
        c2.metric("Unbilled milestone value (one-time cash)", dt.inr(ms.extra["unbilled_exposure_inr"]))
    if sa:
        c3.metric("Orphaned SaaS cost / yr", dt.inr(sa.annualised_inr), delta=f"{sa.rows_flagged} seats", delta_color="off")
    a, b = st.columns(2)
    if ms and len(ms.evidence):
        with a:
            st.markdown("#### Milestones by days beyond grace period")
            buckets = pd.cut(ms.evidence["delay_days"], [0, 7, 14, 30, 10_000],
                             labels=["1-7", "8-14", "15-30", "30+"])
            st.bar_chart(buckets.value_counts().sort_index(), color="#2563eb")
            st.markdown("#### Largest delayed milestones")
            st.dataframe(ms.evidence.sort_values("value_inr", ascending=False)
                         .head(10)[["project", "client", "value_inr", "status", "lag_days"]], hide_index=True)
    if sa and len(sa.evidence):
        with b:
            st.markdown("#### Orphaned SaaS cost by application (₹ Lakhs / yr)")
            st.bar_chart(sa.evidence.groupby("app")["impact_inr"].sum() / 1e5, color="#1e3a8a")
            st.markdown("#### Seats to review")
            st.dataframe(sa.evidence[["app", "user_email", "monthly_cost_inr", "days_inactive", "status"]]
                         .head(15), hide_index=True)
    if ms:
        st.caption(ms.caveat)

# ============================================================== 5. ACTION QUEUE
elif page == PAGES[5]:
    st.subheader("Action Queue: recommended actions need human approval")
    st.markdown("<div class='plain'>ArcheNex recommends; a person decides. Every decision is logged below. "
                "In this version ArcheNex does <b>not</b> change payroll, HRIS or ERP data; approved "
                "actions are handed to the owning team.</div>", unsafe_allow_html=True)
    actions = ag.recommend_actions(findings, cfg)
    log = st.session_state.setdefault("approval_log", [])
    decided = {e["action_id"]: e["decision"] for e in log}
    who = reviewer.strip() or "Unnamed reviewer"

    for a in actions:
        with st.container(border=True):
            st.markdown(f"**{a['title']}**")
            st.caption(f"Owner: {a['owner']} · Estimated impact: {dt.inr(a['impact_inr_annual'])} / yr")
            st.write(a["detail"])
            if a["id"] in decided:
                st.info(f"Decision recorded: **{decided[a['id']]}**")
            else:
                b1, b2, b3, _ = st.columns([1, 1, 1, 4])
                for col, label in ((b1, "Approve"), (b2, "Reject"), (b3, "Defer")):
                    if col.button(label, key=f"{label}_{a['id']}"):
                        log.append({"timestamp": now_stamp(), "reviewer": who, "action_id": a["id"],
                                    "action": a["title"], "decision": label})
                        st.rerun()

    st.markdown("#### Decision audit trail")
    trail = ag.audit_trail_df(log)
    st.dataframe(trail, hide_index=True)
    if len(trail):
        st.download_button("Download audit trail (CSV)", trail.to_csv(index=False).encode("utf-8"),
                           file_name="archenex_decision_trail.csv", mime="text/csv")
    st.caption("The trail lives in this browser session. A persistent, tamper-evident store is on the roadmap.")

    api_key = _secret("ANTHROPIC_API_KEY")
    st.markdown("#### Optional: AI-written CFO brief")
    if api_key:
        st.caption("Sends only aggregated totals (no employee IDs or e-mails) to Claude.")
        if st.button("Generate CFO brief"):
            with st.spinner("Writing brief…"):
                st.session_state["ai_brief"] = ag.ai_brief(ag.summary_text(findings, summary), api_key)
        if st.session_state.get("ai_brief"):
            st.markdown(st.session_state["ai_brief"])
    else:
        st.caption("Disabled. Add ANTHROPIC_API_KEY to Streamlit Secrets to enable (see README).")

# ============================================================ 6. REPORT & VERIFY
elif page == PAGES[6]:
    st.subheader("Boardroom Report & Verification")
    fp, canonical = dt.build_fingerprint(client_name, data_basis, data, cfg, findings)
    meta = {"client": client_name, "sector": industry, "hris": hris, "erp": erp,
            "data_basis": data_basis, "is_demo": is_demo}

    st.markdown("#### Integrity fingerprint (SHA-256)")
    st.code(fp, language=None)
    st.caption("Computed over the input-file hashes, every assumption and every finding. Change any of them "
               "and the fingerprint changes. It proves the report has not been altered; it is not a digital signature.")

    if st.button("Build PDF report"):
        with st.spinner("Building report…"):
            st.session_state["pdf"] = {"fp": fp, "bytes": build_pdf(meta, findings, summary, cfg, fp, reviewer)}
    pdf = st.session_state.get("pdf")
    c1, c2, c3 = st.columns(3)
    if pdf and pdf["fp"] == fp:
        c1.download_button("Download PDF report", pdf["bytes"],
                           file_name=f"ArcheNex_Audit_{client_name.split()[0]}.pdf", mime="application/pdf")
    elif pdf:
        c1.warning("Inputs or assumptions changed. Rebuild the PDF.")
    c2.download_button("Download findings JSON (for verification)", canonical.encode("utf-8"),
                       file_name="archenex_findings.json", mime="application/json")
    log = pd.concat([f.evidence[dt._STD].assign(rule=f.title) for f in findings], ignore_index=True)
    c3.download_button("Download full audit log (CSV)", log.to_csv(index=False).encode("utf-8"),
                       file_name="archenex_audit_log.csv", mime="text/csv")

    st.markdown("#### Verify a report")
    st.caption("Upload the findings JSON that came with a report and compare it with the fingerprint printed on that report.")
    claimed = st.text_input("Fingerprint printed on the report", value="")
    upl = st.file_uploader("Findings JSON", type=["json"], key="verify_json")
    if upl is not None:
        computed = dt.sha256_bytes(upl.getvalue())
        st.code(computed, language=None)
        if claimed.strip():
            if hmac.compare_digest(computed.lower(), claimed.strip().lower()):
                st.success("MATCH: the findings file is exactly what the report was fingerprinted on.")
            else:
                st.error("NO MATCH: the file or the report has been altered, or they belong to different runs.")
        else:
            st.info("Paste the fingerprint from the report to compare.")

    st.markdown("#### Executive summary")
    st.markdown(
        f"<div class='plain'><b>Organisation:</b> {html.escape(client_name)}<br>"
        f"<b>Data basis:</b> {data_basis}<br>"
        f"<b>Identified annual leakage:</b> {dt.inr(summary['identified_annual'])} · "
        f"<b>Addressable:</b> {dt.inr(summary['addressable_annual'])} · "
        f"<b>Return on fee:</b> {summary['roi_multiple']:.1f}x</div>", unsafe_allow_html=True)
